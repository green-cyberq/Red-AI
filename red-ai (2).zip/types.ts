
export interface TranscriptItem {
  speaker: 'User' | 'AI';
  text?: string;
}
